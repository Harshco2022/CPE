<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance GPT - Financial Institutions & Markets</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link rel="stylesheet" href="cards.css"> <!-- Link to external CSS -->

   </head>
<body>

<div class="container">
    <!-- Heading and Introduction -->
    <div class="heading">
        <h1 class="primary-color">Personal Finance Management</h1>
    </div>
    <div class="description">
        <p class="secondary-color">Financial security and independence begin with effective personal finance management. This course teaches students how to take control of their financial future by learning the fundamentals of budgeting, saving, investing, and debt management. Topics include setting short-term and long-term financial goals, creating a personal budget, managing credit and loans, understanding taxes, and planning for retirement. Students will also learn about various investment options, such as mutual funds, bonds, and real estate, and how to build a diversified portfolio based on risk tolerance and financial objectives. The course emphasizes practical financial planning techniques, helping students make informed decisions about their money. Real-world case studies, budgeting exercises, and financial planning tools will prepare students to confidently manage their personal finances and build wealth over time.</p>
    </div>

    <!-- PDF Viewer -->
    <div class="pdf-container">
        <iframe class="pdf-viewer" src="pdf/personal-finance-management.pdf" title="Financial Institutions & Markets PDF"></iframe>
    </div>

    <!-- Back Button -->
    <div class="back-button" onclick="goBackToCourses()">Back to Courses Page</div>
</div>

<script>
    // Function to go back to the courses page
    function goBackToCourses() {
        window.history.back();
    }
</script>

</body>
</html>
