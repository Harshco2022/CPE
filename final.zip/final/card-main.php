<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance GPT - Courses We Offer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* CSS Variables */
        :root {
            --e-global-color-primary: #1976D2;
            --e-global-color-secondary: #FFC107;
            --e-global-color-text: #7A7A7A;
            --e-global-color-accent: #61CE70;
            --e-global-typography-primary-font-family: "Roboto";
            --e-global-typography-primary-font-weight: 600;
            --e-global-typography-secondary-font-family: "Roboto Slab";
            --e-global-typography-secondary-font-weight: 400;
            --e-global-typography-text-font-family: "Roboto";
            --e-global-typography-text-font-weight: 400;
            --e-global-typography-accent-font-family: "Roboto";
            --e-global-typography-accent-font-weight: 500;
        }

        /* Body styles */
        body {
            font-family: var(--e-global-typography-text-font-family);
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            color: var(--e-global-color-text);
        }

        /* New Classes for Primary and Secondary Colors */
        .primary-color {
            color: var(--e-global-color-primary);
        }

        .secondary-color {
            color: var(--e-global-color-secondary);
        }

        /* Utility classes for background colors */
        .bg-primary {
            background-color: var(--e-global-color-primary);
        }

        .bg-secondary {
            background-color: var(--e-global-color-secondary);
        }

        /* Container */
        .container {
            width: 80%;
            margin: 0 auto;
        }

        /* Heading */
        .heading {
            text-align: center;
            margin-top: 30px;
            font-size: 2.5rem;
            color: var(--e-global-color-primary);
            font-weight: var(--e-global-typography-primary-font-weight);
        }

        .description {
            text-align: center;
            margin: 20px 0;
            font-size: 1.1rem;
            color: var(--e-global-color-secondary);
        }

        .cards-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: space-between;
            margin-top: 30px;
        }




        .card {
            background-color: #fff;
            padding: 25px;
            border-radius: 10px;
            width: 30%;
           // box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, background-color 0.3s ease;
            cursor: pointer;
            text-align: center;
            height: 450px;  /* Increased height to give room for description */
            display: flex;
            flex-direction: column;
            justify-content: space-between;  /* Ensures content is distributed evenly */
        }

        .card:hover {
            background-color: #39FF14;  /* Primary Color on hover */
            transform: scale(1.05);
          //  box-shadow: 0 0 20px 5px rgba(0, 0, 255, 0.7);  /* Blue Glow on hover */
        }

        .card-icon {
            font-size: 3.5rem;  /* Increased icon size */
            color: #000000;      /* Icon color changed to black */
            margin-bottom: 15px;
        }

        .card-title {
            font-size: 1.4rem;
            font-weight: 600;
            color: #54595F;  /* Secondary color */
            margin-bottom: 15px;
        }

        .card-description {
            font-size: 1.1rem;
            color: #7A7A7A;  /* Text color */
            line-height: 1.6;
            flex-grow: 1;  /* Allows description to take available space */
        }

        .card-footer {
            margin-top: 15px;
            font-size: 1rem;
            color: #54595F;
            font-weight: 500;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .card {
                width: 100%;
                margin-bottom: 20px;  /* Adds some space between cards on small screens */
            }
        }

        



        

        .course-details {
            margin-top: 30px;
        }

        .course-title {
            font-size: 2.5rem;
            text-align: center;
            color: var(--e-global-color-primary);
        }

        .course-description {
            margin-top: 20px;
            text-align: center;
            font-size: 1.1rem;
            color: var(--e-global-color-secondary);
        }

        .pdf-container {
            display: flex;
            justify-content: center;
            margin-top: 30px;
        }

        .pdf-viewer {
            width: 100%;
            height: 600px;
            border: none;
        }

        /* Back button style */
        .back-button {
            display: block;
            width: 200px;
            padding: 10px;
            background-color: var(--e-global-color-accent);
            color: white;
            text-align: center;
            margin: 20px auto;
            border-radius: 5px;
            font-size: 1.1rem;
            cursor: pointer;
        }

        .back-button:hover {
            background-color: #45b158;
        }

        /* Hide course details initially */
        #course-details {
            display: none;
        }

        /* Row specific styles for two rows of cards */
        .first-row, .second-row {
            display: flex;
            gap: 20px;
            justify-content: space-between;
        }

        /* Custom font styles for different sections */
        .custom-font-primary {
            font-family: var(--e-global-typography-primary-font-family);
        }

        .custom-font-secondary {
            font-family: var(--e-global-typography-secondary-font-family);
        }
        .card-icon {
            font-size: 3.5rem;  /* Increased icon size */
            color: #000000;      /* Icon color */
            margin-bottom: 15px;
        }

    </style>
</head>
<body>

<div class="container">
    <!-- Heading and Introduction -->
    <div class="heading">
        <h1 class="primary-color">Courses We Offer</h1>
    </div>
    <div class="description">
        <p class="secondary-color">Welcome to Finance GPT – Your Ultimate Finance Learning Hub!</p>
        <p class="secondary-color">In the ever-evolving world of finance, staying ahead requires the right knowledge, skills, and insights. Finance GPT is your gateway to mastering finance through expertly curated course materials designed for beginners, professionals, and finance enthusiasts alike. Whether you're looking to understand the fundamentals of financial markets, sharpen your investment strategies, or explore cutting-edge financial technologies, we provide comprehensive, easy-to-understand, and up-to-date content to help you succeed.</p>
    </div>

    <!-- Cards Section Row 1 -->
    <div class="container">
    <div class="first-row">
        <!-- Card 1: Financial Institutions & Markets -->

        <div class="card" >
                            <a href="financial-institutions-markets.php">

            <i class="fas fa-university card-icon"></i>  <!-- Font Awesome Icon -->
            <div class="card-title">Financial Institutions & Markets</div>
            <div class="card-description">
                This course provides an in-depth understanding of financial institutions such as banks, insurance companies, and mutual funds, as well as their critical role in global markets. Learn how these institutions help manage risk, allocate capital, and facilitate economic growth.
            </div>
            <div class="card-footer">Click to explore more</div>
            </a>

        </div>
        <!-- Card 2: Stock Investing -->


        <div class="card" >
                            <a href="stock-investing.php">

            <i class="fas fa-chart-line card-icon"></i>  <!-- Font Awesome Icon -->
            <div class="card-title">Stock Investing</div>
            <div class="card-description">
                Gain essential knowledge about stock market investing! This course will teach you how to analyze stocks, understand market trends, and develop strategies to build a successful investment portfolio. Perfect for those new to investing or looking to refine their skills.
            </div>
            <div class="card-footer">Click to explore more</div>
            </a>

        </div>
        <!-- Card 3: Personal Finance Management -->

        <div class="card" >
                            <a href="personal-finance-management.php">

            <i class="fas fa-wallet card-icon"></i>  <!-- Font Awesome Icon -->
            <div class="card-title">Personal Finance Management</div>
            <div class="card-description">
                This course covers all the essential aspects of managing your personal finances, from budgeting and saving to investing and retirement planning. Learn to take control of your financial future, reduce debt, and achieve long-term financial security.
            </div>
            <div class="card-footer">Click to explore more</div>
                </a>

        </div>
    </div>
<br><br>
    <div class="second-row">
        <!-- Card 4: Investment Analysis and Policy -->

        <div class="card" >
                            <a href="investment-analysis-policy.php">

            <i class="fas fa-search-dollar card-icon"></i>  <!-- Font Awesome Icon -->
            <div class="card-title">Investment Analysis and Policy</div>
            <div class="card-description">
                Learn the art and science of analyzing investments. This course introduces you to investment theories, asset valuation, and risk management techniques. Develop a solid foundation in evaluating investment opportunities to make informed decisions.
            </div>
            <div class="card-footer">Click to explore more</div>
            </a>

        </div>
        <!-- Card 5: Corporate Finance -->
        <div class="card" >
                            <a href="corporate-finance.php">

            <i class="fas fa-briefcase card-icon"></i>  <!-- Font Awesome Icon -->
            <div class="card-title">Corporate Finance</div>
            <div class="card-description">
                Corporate finance is crucial for any business decision. This course will provide an in-depth understanding of capital structure, corporate governance, mergers and acquisitions, and financial strategies to enhance a company's value.
            </div>
            <div class="card-footer">Click to explore more</div>
                </a>

        </div>

        <!-- Card 6: Financial Accounting -->
        <div class="card" >
                    <a href="financial-accounting.php">

            <i class="fas fa-calculator card-icon"></i>  <!-- Font Awesome Icon -->
            <div class="card-title">Financial Accounting</div>
            <div class="card-description">
                Master the basics of accounting and learn to interpret financial statements. This course provides an introduction to financial accounting principles and practices, including balance sheets, income statements, and cash flow analysis.
            </div>
            <div class="card-footer">Click to explore more</div>
        </a>
        </div>
    </div>
</div>

<br><br>

</body>
</html>
