<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance GPT - Financial Institutions & Markets</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link rel="stylesheet" href="cards.css"> <!-- Link to external CSS -->

    
<body>

<div class="container">
    <!-- Heading and Introduction -->
    <div class="heading">
        <h1 class="primary-color">Stock Investing</h1>

    </div>
    <div class="description">
        <p class="secondary-color">This course is designed to provide students with the foundational knowledge and practical skills needed to invest in stocks successfully. It covers the fundamentals of the stock market, including how stocks are traded, how market indices function, and the factors that influence stock prices. Students will explore different investment strategies, such as value investing, growth investing, and dividend investing, and learn to analyze stocks using fundamental and technical analysis. The course also introduces concepts like risk management, portfolio diversification, and behavioral finance, helping students develop a disciplined approach to investing. Case studies, real-world market simulations, and stock portfolio management exercises will allow students to apply their knowledge in practical scenarios. By the end of the course, students will have a strong foundation in stock investing and the confidence to make informed investment decisions.</p>
    </div>

    <!-- PDF Viewer -->
    <div class="pdf-container">
        <iframe class="pdf-viewer" src="pdf/stock-investing.pdf" title="Financial Institutions & Markets PDF"></iframe>
    </div>

    <!-- Back Button -->
    <div class="back-button" onclick="goBackToCourses()">Back to Courses Page</div>
</div>

<script>
    // Function to go back to the courses page
    function goBackToCourses() {
        window.history.back();
    }
</script>

</body>
</html>
