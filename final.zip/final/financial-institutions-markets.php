<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance GPT - Financial Institutions & Markets</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link rel="stylesheet" href="cards.css"> <!-- Link to external CSS -->

   </head>
<body>

<div class="container">
    <!-- Heading and Introduction -->
    <div class="heading">
        <h1 class="primary-color">Financial Institutions & Markets</h1>
    </div>
    <div class="description">
        <p class="secondary-color">This course provides an in-depth understanding of financial institutions and markets, which play a vital role in the global economy. Students will explore different types of financial institutions, including commercial banks, investment banks, insurance companies, pension funds, and mutual funds, learning how they facilitate capital flow and economic stability. The course also delves into financial markets, such as money markets, bond markets, and stock exchanges, analyzing how they operate, their regulatory frameworks, and their impact on businesses and individuals. Additionally, students will examine monetary policy, interest rates, and global financial trends to understand how financial markets respond to economic changes. By the end of the course, students will be equipped with the knowledge to navigate financial institutions and market structures, making informed decisions in banking, investments, and corporate finance.</p>
    </div>

    <!-- PDF Viewer -->
    <div class="pdf-container">
        <iframe class="pdf-viewer" src="pdf/financial-institutions-markets.pdf" title="Financial Institutions & Markets PDF"></iframe>
    </div>

    <!-- Back Button -->
    <div class="back-button" onclick="goBackToCourses()">Back to Courses Page</div>
</div>

<script>
    // Function to go back to the courses page
    function goBackToCourses() {
        window.history.back();
    }
</script>

</body>
</html>
