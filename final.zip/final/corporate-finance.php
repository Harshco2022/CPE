<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance GPT - Financial Institutions & Markets</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link rel="stylesheet" href="cards.css"> <!-- Link to external CSS -->

    
<body>

<div class="container">
    <!-- Heading and Introduction -->
    <div class="heading">
        <h1 class="primary-color">Corporate Finance</h1>

    </div>
    <div class="description">
        <p class="secondary-color">Corporate finance is the backbone of business decision-making, and this course provides a comprehensive understanding of how organizations manage their financial resources to maximize value. Students will explore key concepts such as capital budgeting, financial forecasting, working capital management, and capital structure optimization. The course examines various financing options, including equity financing, debt financing, and venture capital, helping students understand how businesses raise and allocate funds. Additionally, topics such as mergers and acquisitions, dividend policy, and risk management will be covered to provide insights into corporate financial strategies. The course combines theoretical knowledge with practical applications, including financial modeling, case studies, and corporate financial decision-making simulations. By the end of the course, students will be prepared to analyze and solve complex financial problems in a corporate setting.</p>
    </div>

    <!-- PDF Viewer -->
    <div class="pdf-container">
        <iframe class="pdf-viewer" src="pdf/corporate-finance.pdf" title="Financial Institutions & Markets PDF"></iframe>
    </div>

    <!-- Back Button -->
    <div class="back-button" onclick="goBackToCourses()">Back to Courses Page</div>
</div>

<script>
    // Function to go back to the courses page
    function goBackToCourses() {
        window.history.back();
    }
</script>

</body>
</html>
