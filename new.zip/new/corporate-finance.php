<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance GPT - Financial Institutions & Markets</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link rel="stylesheet" href="cards.css"> <!-- Link to external CSS -->

    
<body>
 <!-- Header with Navigation Menu -->
    <header>
      <!--  <nav>
            <div class="logo">
                <a href="/" style="color: white; text-decoration: none; font-size: 1.6rem; font-weight: 700;">Finance GPT</a>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about-us.php">About Us</a></li>
                <li><a href="courses.php">Courses</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>-->
    </header>
<div class="container">
    <!-- Heading and Introduction -->
    <div class="heading">
        <h1 class="primary-color">Corporate Finance</h1>

    </div>
    <div class="description">
        <p class="secondary-color">Corporate finance is the backbone of business decision-making, and this course provides a comprehensive understanding of how organizations manage their financial resources to maximize value. Students will explore key concepts such as capital budgeting, financial forecasting, working capital management, and capital structure optimization. The course examines various financing options, including equity financing, debt financing, and venture capital, helping students understand how businesses raise and allocate funds. Additionally, topics such as mergers and acquisitions, dividend policy, and risk management will be covered to provide insights into corporate financial strategies. The course combines theoretical knowledge with practical applications, including financial modeling, case studies, and corporate financial decision-making simulations. By the end of the course, students will be prepared to analyze and solve complex financial problems in a corporate setting.</p>
    </div>

    <!-- PDF Viewer -->
    <div class="pdf-container">
        <iframe class="pdf-viewer" src="pdf/corporate-finance.pdf" title="Financial Institutions & Markets PDF"></iframe>
    </div>

    <!-- Back Button -->
    <div class="back-button" onclick="goBackToCourses()">Back to Courses Page</div>
</div>

<script>
    // Function to go back to the courses page
    function goBackToCourses() {
        window.history.back();
    }
</script>
 <!-- Footer with Contact Info -->
    <footer>
        <div class="footer-info">
           <!-- <p>Contact Us: <a href="mailto:contact@financegpt.com">contact@financegpt.com</a></p>
            <p>Address: 123 Finance St, Suite 101, New York, NY 10001</p>-->
        </div>
    </footer>

</body>
</html>
