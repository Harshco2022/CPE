<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance GPT - Financial Institutions & Markets</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
        <link rel="stylesheet" href="cards.css"> <!-- Link to external CSS -->

   </head>
<body>
<!-- Header with Navigation Menu -->
    <header>
      <!--  <nav>
            <div class="logo">
                <a href="/" style="color: white; text-decoration: none; font-size: 1.6rem; font-weight: 700;">Finance GPT</a>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about-us.php">About Us</a></li>
                <li><a href="courses.php">Courses</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>-->
    </header>
<div class="container">
    <!-- Heading and Introduction -->
    <div class="heading">
        <h1 class="primary-color">Financial Institutions & Markets</h1>
    </div>
    <div class="description">
        <p class="secondary-color">This course provides an in-depth understanding of financial institutions and markets, which play a vital role in the global economy. Students will explore different types of financial institutions, including commercial banks, investment banks, insurance companies, pension funds, and mutual funds, learning how they facilitate capital flow and economic stability. The course also delves into financial markets, such as money markets, bond markets, and stock exchanges, analyzing how they operate, their regulatory frameworks, and their impact on businesses and individuals. Additionally, students will examine monetary policy, interest rates, and global financial trends to understand how financial markets respond to economic changes. By the end of the course, students will be equipped with the knowledge to navigate financial institutions and market structures, making informed decisions in banking, investments, and corporate finance.</p>
    </div>

    <!-- PDF Viewer -->
    <div class="pdf-container">
        <iframe class="pdf-viewer" src="pdf/financial-institutions-markets.pdf" title="Financial Institutions & Markets PDF"></iframe>
    </div>

    <!-- Back Button -->
    <div class="back-button" onclick="goBackToCourses()">Back to Courses Page</div>
</div>

<script>
    // Function to go back to the courses page
    function goBackToCourses() {
        window.history.back();
    }
</script>
<!-- Footer with Contact Info -->
    <footer>
        <div class="footer-info">
           <!-- <p>Contact Us: <a href="mailto:contact@financegpt.com">contact@financegpt.com</a></p>
            <p>Address: 123 Finance St, Suite 101, New York, NY 10001</p>-->
        </div>
    </footer>
</body>
</html>
