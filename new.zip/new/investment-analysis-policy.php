<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance GPT - Financial Institutions & Markets</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
       <link rel="stylesheet" href="cards.css"> <!-- Link to external CSS -->

</head>
<body>
<!-- Header with Navigation Menu -->
    <header>
      <!--  <nav>
            <div class="logo">
                <a href="/" style="color: white; text-decoration: none; font-size: 1.6rem; font-weight: 700;">Finance GPT</a>
            </div>
            <ul class="nav-menu">
                <li><a href="index.php">Home</a></li>
                <li><a href="about-us.php">About Us</a></li>
                <li><a href="courses.php">Courses</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>-->
    </header>
<div class="container">
    <!-- Heading and Introduction -->
    <div class="heading">
        <h1 class="primary-color">Investment Analysis and Policy</h1>
    </div>
    <div class="description">
        <p class="secondary-color">Investment decisions require careful analysis and a well-defined policy to achieve financial goals. This course provides students with the tools and frameworks necessary to assess investment opportunities, develop investment strategies, and create policies that align with risk tolerance and return expectations. The course covers risk-return trade-offs, asset valuation techniques, portfolio management strategies, and capital market theories. Students will explore various asset classes, including equities, bonds, real estate, and alternative investments, learning how to analyze financial statements, industry trends, and macroeconomic factors. Additionally, the course introduces investment policy formulation, focusing on setting guidelines for asset allocation, diversification, and performance measurement. Through case studies and practical investment simulations, students will gain hands-on experience in managing investments effectively.</p>
    </div>

    <!-- PDF Viewer -->
    <div class="pdf-container">
        <iframe class="pdf-viewer" src="pdf/investment-analysis-policy.pdf" title="Financial Institutions & Markets PDF"></iframe>
    </div>

    <!-- Back Button -->
    <div class="back-button" onclick="goBackToCourses()">Back to Courses Page</div>
</div>

<script>
    // Function to go back to the courses page
    function goBackToCourses() {
        window.history.back();
    }
</script>
<!-- Footer with Contact Info -->
    <footer>
        <div class="footer-info">
           <!-- <p>Contact Us: <a href="mailto:contact@financegpt.com">contact@financegpt.com</a></p>
            <p>Address: 123 Finance St, Suite 101, New York, NY 10001</p>-->
        </div>
    </footer>
</body>
</html>
